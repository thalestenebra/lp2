#include "cadasequip.h"
#include "ui_cadasequip.h"
#include "menucadas.h"
#include "QString"
#include "QSqlQuery"
#include "QMessageBox"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "menuempres.h"
#include "dadoslogin.h"

CadasEquip::CadasEquip(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CadasEquip)
{
    ui->setupUi(this);

    QStringList CompletionList;
    QSqlQuery query;
    QString cod;


    query.prepare("select IdLaboratorio from laboratorio where Estado=true ");
    if(query.exec()){
        while(query.next()){
            cod = query.value(0).toString();
            CompletionList << cod;
        }
    }

    StringCompleter = new QCompleter(CompletionList, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->localizacao->setCompleter(StringCompleter);

    ui->label_nome->setText(nome1);
}

CadasEquip::~CadasEquip()
{
    delete ui;
}

void CadasEquip::on_pushButton_3_clicked()
{
    MenuCadas menucadas;
    menucadas.setModal(true);
    menucadas.exec();
}

void CadasEquip::on_btn_confirma_clicked()
{
    QString codigo = ui->cod->text();
    QString descricao = ui->descricao->toPlainText();
    QString localizacao = ui->localizacao->text();
    QString data_aq = ui->data_aquisicao->text();
    QString fornecedor = ui->fornecedor->text();
    QString nota_fiscal = ui->nota_fiscal->text();
    QString garantia = ui->garantia->text();
    QString data_fiscal = ui->data_fiscal->text();
    QString aquisicao = ui->aquisicao->text();
    QString solicitante = ui->solicitante->text();
    bool reativar = false;
    bool aux = true;

    //chave estrangeira é int
    int lab;

    //mudança na data para ficar no padrão do mysql
    QString data1 = data_aq.right(4) + "-" + data_aq.mid(3, 2) + "-" + data_aq.left(2);
    QString data2 = data_fiscal.right(4) + "-" + data_fiscal.mid(3, 2) + "-" + data_fiscal.left(2);
    QString data3 = garantia.right(4) + "-" + garantia.mid(3, 2) + "-" + garantia.left(2);

    QPalette paleta;
    paleta.setColor(QPalette::WindowText, Qt::red);
    ui->mensagem->setPalette(paleta);


    //código, descrição e localização devem ser preenchidos
    if (codigo.size() == 0 || descricao.size() == 0 || localizacao.size() == 0) {
        ui->mensagem->setText("Os campos com asterisco não podem ficar em branco");
    } else {
        QSqlQuery query;
        int count = 0;
        aux = true;


        //verificando se o código do equipamento já existe
        //EstadoEmpres->false(não está emprestado)
        //EstadoExcluir->false(não é um equipamento que foi excluído)
        query.prepare("select CodEquipamento from equipamento where IdEquipamento='"+codigo+"' and EstadoExcluir=false");
        if (query.exec()) {
            while(query.next()) {
                count++;
            }
            if (count > 0) {
                aux = false;
                ui->mensagem->setText("Código do equipamento já está sendo usado");
            }
        }
        count = 0;


        //verificando se o código do laboratório existe
        query.prepare("select CodLaboratorio from laboratorio where IdLaboratorio='"+localizacao+"' and Estado=true");
        if (query.exec()) {
            while(query.next()) {
                lab = query.value(0).toInt();
                count++;
            }
            if (count != 1){
                aux = false;
                ui->mensagem->setText("Código do laboratório inserido não existe");
            }
        }
        count = 0;

        //verificando se o código do equipamento já existe e está desativado;
        //caso esteja, dar a opção para o usuário de reativa-lo alterando(update) os dados
        //para o que ele preencheu no cadastrar(menos o siape)
        query.prepare("select CodEquipamento from equipamento where IdEquipamento='"+codigo+"' and EstadoExcluir=true ");
        if (query.exec()) {
            while(query.next()) {
                count++;
            }
            if(count == 1 && aux == true) {
                reativar = true;
            }
        }

        count = 0;

        if (reativar == true) {
            QMessageBox msgBox;
            msgBox.setInformativeText( "Um equipamento com este código já foi"
            " cadastrado anteriormente, mas está desativado.\nDeseja reativá-lo e mudar os dados"
            " para os preenchidos no cadastro?");
            QAbstractButton *sim = msgBox.addButton("Sim", QMessageBox::YesRole);
            QAbstractButton *nao = msgBox.addButton("Não", QMessageBox::NoRole);
            msgBox.setIcon(QMessageBox::Question);
            msgBox.exec();
            if (msgBox.clickedButton() == sim) {
                query.prepare("update equipamento set Descricao=?,DataAquisicao=?,Fornecedor=?,NotaFiscal=?,TempoGarantia=?,"
                "DataNotaFiscal=?,ProcessoAquisicao=?,Solicitante=?,IdEquipamento=?,Laboratorio=? where IdEquipamento='"+codigo+"' ");
                query.addBindValue(descricao);
                query.addBindValue(data1);
                query.addBindValue(fornecedor);
                query.addBindValue(nota_fiscal);
                query.addBindValue(data3);
                query.addBindValue(data2);
                query.addBindValue(aquisicao);
                query.addBindValue(solicitante);
                query.addBindValue(codigo);
                query.addBindValue(lab);
                if (query.exec()) {
                    paleta.setColor(QPalette::WindowText, Qt::darkGreen);
                    ui->mensagem->setPalette(paleta);
                    ui->mensagem->setText("Equipamento reativado com sucesso");
                }
            }
         }

        //tentiva de inserção no banco de dados
        if(aux == true && reativar == false) {
            query.prepare("insert into equipamento (Descricao,DataAquisicao,Fornecedor,NotaFiscal,TempoGarantia,"
            "DataNotaFiscal,ProcessoAquisicao,Solicitante,IdEquipamento,Laboratorio,EstadoEmpres,EstadoExcluir)"
            "values(?,?,?,?,?,?,?,?,?,?,?,?)");
            query.addBindValue(descricao);
            query.addBindValue(data1);
            query.addBindValue(fornecedor);
            query.addBindValue(nota_fiscal);
            query.addBindValue(data3);
            query.addBindValue(data2);
            query.addBindValue(aquisicao);
            query.addBindValue(solicitante);
            query.addBindValue(codigo);
            query.addBindValue(lab);
            query.addBindValue(false);
            query.addBindValue(false);
            if (query.exec()) {
                paleta.setColor(QPalette::WindowText, Qt::darkGreen);
                ui->mensagem->setPalette(paleta);
                ui->mensagem->setText("Equipamento cadastrado com sucesso");
            } else {

                ui->mensagem->setText("erro ao cadastrar no banco de dados");
            }
        }
    }
}

void CadasEquip::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void CadasEquip::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

void CadasEquip::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
