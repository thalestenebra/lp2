#include "consusuarios.h"
#include "ui_consusuarios.h"
#include "consultaprincipal.h"
#include "QSqlQuery"
#include "nomesiapeproxmodel.h"
#include "alteraruser.h"
#include "removeuser.h"
#include "dadoslogin.h"

/*#include "QPrinter"
#include "QPainter"*/

ConsUsuarios::ConsUsuarios(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsUsuarios)
{
    ui->setupUi(this);

    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)),
    SLOT(customMenuRequested(QPoint)));

    //Trazer os dados da tabela
    modUsuario = new QSqlRelationalTableModel(this, cn::db());
    modUsuario->setTable("usuario");
    modUsuario->select();
    modUsuario->setHeaderData(1, Qt::Horizontal, QObject::tr("Nome"));
    modUsuario->setHeaderData(2, Qt::Horizontal, QObject::tr("E-mail"));
    modUsuario->setHeaderData(4, Qt::Horizontal, QObject::tr("SIAPE"));

    //Filtro

    //modUsuario->setFilter(QString("Nome like '%sfwess%' "));

    ui->tableView->setModel(modUsuario);
    ui->tableView->hideColumn(0);
    ui->tableView->hideColumn(3);
    ui->tableView->hideColumn(5);
    ui->tableView->hideColumn(6);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    modUsuario->setFilter("Estado=true");




    QHeaderView *headerView = ui->tableView->horizontalHeader();
    headerView->swapSections(1, 4);
    headerView->swapSections(2,4);


}

ConsUsuarios::~ConsUsuarios()
{
    delete ui;
}

void ConsUsuarios::on_pushButton_3_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}



void ConsUsuarios::on_pushButton_clicked()
{
    /*
    QPainter painter;
    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName("teste.pdf");
            painter.begin(&printer);
            double xscale = printer.pageRect().width()/double(ui->tableWidget->width());
            double yscale = printer.pageRect().height()/double(ui->tableWidget->height());
            double scale = qMin(xscale, yscale);
            painter.translate(printer.paperRect().x() + printer.pageRect().width()/2,
                               printer.paperRect().y() + printer.pageRect().height()/2);
            painter.scale(scale, scale);
            painter.translate(-width()/2, -height()/2);

            ui->tableWidget->render(&painter);
            painter.end();
            */
}

void ConsUsuarios::on_lineEdit_2_textChanged(const QString &arg1)
{

}

void ConsUsuarios::on_nome_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' and Estado=true "));
    ui->tableView->setModel(modUsuario);
}

void ConsUsuarios::on_siape_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' and Estado=true "));
    ui->tableView->setModel(modUsuario);
}

void ConsUsuarios::on_email_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' and Estado=true "));
    ui->tableView->setModel(modUsuario);
}

void ConsUsuarios::on_tableView_customContextMenuRequested(const QPoint &pos)
{
    if (perm == 1) {
        QModelIndex index = ui->tableView->indexAt(pos);
        idconsequi = ui->tableView->model()->index(index.row(), 4).data().toString();
        if(index.isValid()){
             QMenu *menu=new QMenu(this);
             QAction *alterarAction = new QAction("Alterar", this);
             QAction *removerAction = new QAction("Remover", this);
             connect(alterarAction,SIGNAL(triggered()),this,SLOT(alterar()));
             connect(removerAction,SIGNAL(triggered()),this,SLOT(remover()));
             menu->addAction(alterarAction);
             menu->addAction(removerAction);
             menu->popup(ui->tableView->viewport()->mapToGlobal(pos));
        }
   }
}

void ConsUsuarios::on_tableView_clicked(const QModelIndex &index)
{
    if (consequi1 != 0 || consequi2 != 0){
        ui->tableView->setColumnWidth(consequi2, 100);
        ui->tableView->setRowHeight(consequi1, 30);
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
        consequi1 = index.row();
        consequi2 = index.column();
    } else{
        consequi1 = index.row();
        consequi2 = index.column();
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
    }
}

void ConsUsuarios::alterar()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    AlterarUser alteraruser;
    alteraruser.setModal(true);
    this->close();
    alteraruser.exec();
}

void ConsUsuarios::remover()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    RemoveUser removeuser;
    removeuser.setModal(true);
    this->close();
    removeuser.exec();
}
