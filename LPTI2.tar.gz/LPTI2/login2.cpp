#include "login2.h"
#include "ui_login2.h"
#include "sobre.h"
#include "recsenha.h"
#include "menuprinc.h"
#include <QtSql>
#include <QSqlQuery>
#include <QString>
#include "dadoslogin.h"


Login2::Login2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login2)
{
    ui->setupUi(this);
    QSqlDatabase db;
    if(db.isOpen()) {
        ui->bd_connection->setText("Conectado ao banco de dados");
    } else {
        ui->bd_connection->setText("Falha ao conectar no banco de dados");
    }
}

Login2::~Login2()
{
    delete ui;
}

void Login2::on_actionSobre_triggered()
{
    Sobre sobre;
    sobre.setModal(true);
    sobre.exec();
}


void Login2::on_pushButton_2_clicked()
{
    RecSenha recsenha;
    recsenha.setModal(true);
    recsenha.exec();
}


void Login2::on_iniciar_clicked()
{
    QSqlQuery query;
    QString siape = ui->siape->text();
    QString senha = ui->senha->text();
    query.prepare("select SIAPE,Senha from usuario where SIAPE='"+siape+"' and Senha='"+senha+"' and Estado=true ");
    if (query.exec()) {
        int count = 0;
        while(query.next()) {
            count++;
        }
        if(count == 1) {
            siap = siape;
            password = senha;
            MenuPrinc menuprinc;
            menuprinc.setModal(true);
            this->close();
            menuprinc.exec();
        } else {
            ui->falha_conexao->setText("siape ou senha inválido");
        }
    } else {
        ui->falha_conexao->setText("falha ao conectar no banco de dados");
    }
}





