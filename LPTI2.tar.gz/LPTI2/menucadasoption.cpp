#include "menucadasoption.h"
#include "ui_menucadasoption.h"
#include "menucadas.h"
#include "menuprinc.h"
#include "menualterar.h"
#include "menuremove.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"
#include "menuempres.h"

MenuCadasOption::MenuCadasOption(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MenuCadasOption)
{
    ui->setupUi(this);

    ui->label_nome->setText(nome1);
}

MenuCadasOption::~MenuCadasOption()
{
    delete ui;
}

void MenuCadasOption::on_pushButton_clicked()
{
    MenuCadas cadas;
    cadas.setModal(true);
    cadas.exec();
}

void MenuCadasOption::on_pushButton_4_clicked()
{
    MenuPrinc menuprinc;
    menuprinc.setModal(true);
    menuprinc.exec();
}

void MenuCadasOption::on_pushButton_2_clicked()
{
    MenuAlterar menualterar;
    menualterar.setModal(true);
    menualterar.exec();
}

void MenuCadasOption::on_pushButton_3_clicked()
{
    MenuRemove menuremove;
    menuremove.setModal(true);
    menuremove.exec();
}



void MenuCadasOption::on_cadastro_2_clicked()
{

    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }

}



void MenuCadasOption::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

void MenuCadasOption::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
