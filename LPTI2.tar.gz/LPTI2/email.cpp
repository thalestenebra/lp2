#include "email.h"

Email::Email()
{

}
