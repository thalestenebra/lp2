#ifndef ALTERARUSER_H
#define ALTERARUSER_H

#include <QDialog>
#include <QCompleter>


namespace Ui {
class AlterarUser;
}

class AlterarUser : public QDialog
{
    Q_OBJECT

public:
    explicit AlterarUser(QWidget *parent = 0);
    ~AlterarUser();

private slots:
     void on_bnt_Voltar_clicked();

     void on_edit_Siape_textChanged(const QString &arg1);

     void on_bnt_Alterar_clicked();

     void on_check_SuperU_clicked();

     void on_check_CadasLab_clicked();

     void on_check_CadasEqui_clicked();

     void on_check_Consultar_clicked();

     void on_check_Emprestar_clicked();

     void on_cadastro_2_clicked();

     void on_consulta_2_clicked();

private:
    Ui::AlterarUser *ui;
    QCompleter *StringCompleter;
};

#endif // ALTERARUSER_H
