#ifndef ALTERARLAB_H
#define ALTERARLAB_H

#include <QDialog>
#include <QCompleter>

namespace Ui {
class AlterarLab;
}

class AlterarLab : public QDialog
{
    Q_OBJECT

public:
    explicit AlterarLab(QWidget *parent = 0);
    ~AlterarLab();

private slots:
     void on_pushButton_4_clicked();

     void on_setCodigo_textChanged();

     void on_btn_confirma_clicked();

     void on_cadastro_2_clicked();

     void on_consulta_2_clicked();

     void on_emprestimo_2_clicked();

private:
    Ui::AlterarLab *ui;
    QCompleter *StringCompleter;
};

#endif // ALTERARLAB_H
