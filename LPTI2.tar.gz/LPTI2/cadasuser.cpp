#include "cadasuser.h"
#include "ui_cadasuser.h"
#include "menucadas.h"
#include "QSqlQuery"
#include "QDebug"
#include "QVariant"
#include "QtNetwork"
#include "smtp.h"
#include "QMessageBox"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"


CadasUser::CadasUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CadasUser)
{
    ui->setupUi(this);
    QNetworkAccessManager nam;
    QNetworkRequest req(QUrl("http://www.google.com"));
    QNetworkReply *reply = nam.get(req);
    QEventLoop loop;
    connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();
    if(reply->bytesAvailable()) {
       ui->bnt_Cadastrar->setEnabled(true);
    } else {
       ui->bnt_Cadastrar->setEnabled(false);
       QPalette palette;
       palette.setColor(QPalette::WindowText, Qt::red);
       ui->txt_Erro->setPalette(palette);
       ui->txt_Erro->setText("Sem conexão com a internet");
    }

    ui->label_nome->setText(nome1);
}

CadasUser::~CadasUser()
{
    delete ui;
}

bool falha = true;

void CadasUser::on_bnt_Voltar_clicked()
{
    MenuCadas menucadas;
    menucadas.setModal(true);
    menucadas.exec();
}

QString senha2;

void CadasUser::on_bnt_Cadastrar_clicked()
{
    ui->bnt_Cadastrar->setEnabled(true);
    QSqlQuery query;
    QString siape = ui->edit_Siape->text();
    QString nome = ui->edit_Nome->text();
    QString email = ui->edit_Email->text();
    QPalette palette = ui->txt_Erro->palette();

    int aux = true;
    int prof = 0;
    int count = 0;
    bool estado = false;

    if (siape.size() == 0){
        ui->txt_Erro->setText("O campo SIAPE deve ser preenchido.");
        ui->bnt_Cadastrar->setEnabled(true);
    } else if (nome.size() == 0){
        ui->txt_Erro->setText("O campo NOME deve ser preenchido.");
        ui->bnt_Cadastrar->setEnabled(true);
    } else if (email.size() == 0){
        ui->txt_Erro->setText("O campo EMAIL deve ser preenchido.");
        ui->bnt_Cadastrar->setEnabled(true);
    } else{
        ui->txt_Erro->setText("");
        query.prepare("select CodUsuario,SIAPE from usuario where SIAPE='"+siape+"' and Estado=true ");
        if (query.exec()) {
            while(query.next()) {
                prof = query.value(0).toInt();
                count++;
            }
        }
        if (count > 0) {
            aux = false;
            palette.setColor(QPalette::WindowText, Qt::red);
            ui->txt_Erro->setPalette(palette);
            //arrumar texto(pode ser siape de professor ou usuário)
            ui->txt_Erro->setText("Este SIAPE já está sendo usado");
        } else{
            bool estadoV = true;
            query.prepare("select Estado from usuario where SIAPE='"+siape+"' ");
            if (query.exec()) {
                while(query.next()) {
                    estadoV = query.value(0).toBool();
                }
            if (estadoV == false) {
                QMessageBox msgBox;
                msgBox.setInformativeText( "Um usuário com este siape já foi"
                " cadastrado anteriormente, mas está desativado.\nDeseja reativá-lo e mudar os dados"
                " para os preenchidos no cadastro?");
                QAbstractButton *sim = msgBox.addButton("Sim", QMessageBox::YesRole);
                QAbstractButton *nao = msgBox.addButton("Não", QMessageBox::NoRole);
                msgBox.setIcon(QMessageBox::Question);
                msgBox.exec();
                if(msgBox.clickedButton() == sim) {

                QString nome = ui->edit_Nome->text();
                QString email = ui->edit_Email->text();
                QString siape = ui->edit_Siape->text();
                QString id;
                QSqlQuery query;
                QPalette palette = ui->txt_Erro->palette();

                query.prepare("select CodUsuario from usuario where SIAPE='"+siape+"' and Estado=true ");
                if (query.exec()) {
                    while(query.next()) {
                        id = query.value(0).toString();
                    }
                }

                if (nome.size() != 0){
                    if (email.size() != 0){
                        if (ui->check_SuperU->isChecked() || ui->check_CadasEqui->isChecked() || ui->check_CadasLab->isChecked() || ui->check_Consultar->isChecked() || ui->check_Emprestar->isChecked()){
                            Smtp* smtp = new Smtp("controledepatrimoniomeca@gmail.com", "bonitasenhorita", "smtp.gmail.com",465);
                            connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
                            srand((unsigned)time(NULL));
                            QString letras = "cbad8efg45hiop6qrxyz12stuvw37jqlmn90";
                            int num;
                            int y;
                            for (num = 0; num < 10; num++) {
                                y = rand() % letras.size();
                                senha2 += letras[y];
                            }
                            ui->txt_Erro->setText("Enviando...");
                            smtp->sendMail("controledepatrimoniomeca@gmail.com", email, "Bem-vindo ao Controle de Patrimônio!",
                            "Prezado usuário " + nome + ",\nSua senha para acessar sua conta é " + senha2);
                            QByteArray criptografia = QCryptographicHash::hash(senha2.toLocal8Bit(),QCryptographicHash::Sha1).toHex();
                            query.prepare("update usuario set senha=? where SIAPE='"+siape+"' ");
                            query.addBindValue(criptografia);
                            query.exec();

                            query.prepare("update usuario set Nome=?,Email=?,Estado=?,Cargo=? where SIAPE='"+siape+"' ");
                                query.addBindValue(nome);
                                query.addBindValue(email);
                                query.addBindValue(true);
                                if(ui->radioProfessor->isChecked()){
                                    query.addBindValue(1);
                                } else{
                                    query.addBindValue(0);
                                }
                                if(query.exec()){
                                } else{
                                    palette.setColor(QPalette::WindowText, Qt::red);
                                    ui->txt_Erro->setPalette(palette);
                                    ui->txt_Erro->setText("Erro ao atribuir nome, email ou cargo");
                                }

                                if(ui->check_SuperU->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                                    query.addBindValue(1);
                                    // Permissao de Super Usuário = 1
                                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                                    query.addBindValue(2);
                                    // Permissao tudo menos emprestar = 2
                                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                                    query.addBindValue(3);
                                    // Permissao tudo menos consultar = 3
                                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                                    query.addBindValue(4);
                                    // Permissao tudo menos cadastrar laboratorio = 4
                                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(5);
                                    // Permissao tudo menos cadastrar equipamento = 5
                                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(6);
                                    // Permissao tudo menos emprestar e consultar = 6
                                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(7);
                                    // Permissao tudo menos emprestar e cadastrar laboratorio = 7
                                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(8);
                                    // Permissao tudo menos emprestar e cadastrar equipamento = 8
                                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(9);
                                    // Permissao tudo menos consultar e cadastrar laboratorio = 9
                                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(10);
                                    // Permissao tudo menos consultar e cadastrar equipamento = 10
                                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(11);
                                  // Permissao tudo menos cadastrar laboratorio e cadastrar equipamento = 11
                                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(12);
                                    // Permissao apenas de emprestar = 12
                                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                                    query.addBindValue(13);
                                 // Permissao apenas de consultar = 13
                                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(14);
                                    // Permissao apenas de cadastrar laboratorio = 14
                                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(15);
                                // Permissao apenas de cadastrar equipamentos = 15
                              } else if (ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked() && !ui->check_SuperU->isChecked()) {
                                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"'");
                                    query.addBindValue(16);
                                }else{
                                    palette.setColor(QPalette::WindowText, Qt::red);
                                    ui->txt_Erro->setPalette(palette);
                                    ui->txt_Erro->setText("Erro ao cadastrar permissão(ões).");
                                }
                                if (query.exec()) {
                                    palette.setColor(QPalette::WindowText, Qt::green);
                                    ui->txt_Erro->setPalette(palette);
                                    ui->txt_Erro->setText("Enviando...");
                               } else {
                                    palette.setColor(QPalette::WindowText, Qt::red);
                                    ui->txt_Erro->setPalette(palette);
                                    ui->txt_Erro->setText("falha ao conectar no banco de dados");
                                }
                                } else{
                                palette.setColor(QPalette::WindowText, Qt::red);
                                ui->txt_Erro->setPalette(palette);
                                ui->txt_Erro->setText("Pelo menos uma permissao deve ser concedida.");
                            }
                        } else {
                            palette.setColor(QPalette::WindowText, Qt::red);
                            ui->txt_Erro->setPalette(palette);
                            ui->txt_Erro->setText("Campo e-mail não pode ficar vazio.");
                        }
                   } else {
                        palette.setColor(QPalette::WindowText, Qt::red);
                        ui->txt_Erro->setPalette(palette);
                        ui->txt_Erro->setText("Campo nome não pode ficar vazio.");
                    }
                }
            } else{

              //caso o usuario nao seja repetido



            if (ui->check_CadasEqui->isChecked() || ui->check_CadasLab->isChecked() || ui->check_Consultar->isChecked() || ui->check_Emprestar->isChecked()){
                Smtp* smtp = new Smtp("controledepatrimoniomeca@gmail.com", "bonitasenhorita", "smtp.gmail.com",465);
                connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
                srand((unsigned)time(NULL));
                QString letras = "cbadefghijqlmnopqrstuvwxyz1234567890";
                int num;
                int y;
                for (num = 0; num < 10; num++) {
                    y = rand() % letras.size();
                    senha2 += letras[y];
                }
                ui->txt_Erro->setText("Enviando...");
                smtp->sendMail("controledepatrimoniomeca@gmail.com", email, "Bem-vindo ao Controle de Patrimônio!",
                "Prezado usuário " + nome + ",\nSua senha para acessar sua conta é " + senha2);
                QByteArray criptografia = QCryptographicHash::hash(senha2.toLocal8Bit(),QCryptographicHash::Sha1).toHex();
                query.prepare("INSERT INTO usuario (Nome,Email,Senha,SIAPE,Cargo,Estado)"
                "VALUES (?,?,?,?,?,?)");
                query.addBindValue(nome);
                query.addBindValue(email);
                query.addBindValue(criptografia);
                query.addBindValue(siape);
                senha2 = "";
                if (ui->radioProfessor->isChecked()){
                    query.addBindValue(1);
                } else{
                    query.addBindValue(0);
                }
                query.addBindValue(true);
                if (query.exec()) {
                    palette.setColor(QPalette::WindowText, Qt::green);
                    ui->txt_Erro->setPalette(palette);
                    //cadastrado com sucesso"(mensagem movida para o mailSent)
                    } else {
                        palette.setColor(QPalette::WindowText, Qt::red);
                        ui->txt_Erro->setPalette(palette);
                        ui->txt_Erro->setText("falha na tentativa de inserção no banco de dados");
                        falha = false;
                        ui->bnt_Cadastrar->setEnabled(true);
                   }
                int aux = 0;
                query.prepare("select CodUsuario from usuario where SIAPE='"+siape+"' and Estado=true ");
                if (query.exec()) {
                    while(query.next()) {
                        aux = query.value(0).toInt();
                    }
                }
                if(ui->check_SuperU->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(1);
                    // Permissao de Super Usuário = 1
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(2);
                    // Permissao tudo menos emprestar = 2
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(3);
                    // Permissao tudo menos consultar = 3
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(4);
                    // Permissao tudo menos cadastrar laboratorio = 4
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(5);
                    // Permissao tudo menos cadastrar equipamento = 5
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(6);
                    // Permissao tudo menos emprestar e consultar = 6
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(7);
                    // Permissao tudo menos emprestar e cadastrar laboratorio = 7
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(8);
                    // Permissao tudo menos emprestar e cadastrar equipamento = 8
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(9);
                    // Permissao tudo menos consultar e cadastrar laboratorio = 9
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(10);
                    // Permissao tudo menos consultar e cadastrar equipamento = 10
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(11);
                    // Permissao tudo menos cadastrar laboratorio e cadastrar equipamento = 11
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(12);
                    // Permissao apenas de emprestar = 12
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(13);
                    // Permissao apenas de consultar = 13
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(14);
                    // Permissao apenas de cadastrar laboratorio = 14
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(15);
                    // Permissao apenas de cadastrar equipamentos = 15
                } else if (ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked() && !ui->check_SuperU->isChecked()) {
                    query.prepare("INSERT INTO permissao (Estado, IdUsuario,Permissao)"
                    "VALUES (?,?,?)");
                    query.addBindValue(1);
                    query.addBindValue(aux);
                    query.addBindValue(16);
                }else{
                    palette.setColor(QPalette::WindowText, Qt::red);
                    ui->txt_Erro->setPalette(palette);
                    ui->txt_Erro->setText("Erro ao cadastrar permissão(ões).");
                    ui->bnt_Cadastrar->setEnabled(true);
                }
                if (query.exec()) {
                    palette.setColor(QPalette::WindowText, Qt::darkGreen);
                    ui->txt_Erro->setPalette(palette);
                    } else {
                        palette.setColor(QPalette::WindowText, Qt::red);
                        ui->txt_Erro->setPalette(palette);
                        ui->txt_Erro->setText("falha na tentativa de inserção no banco de dados");
                        ui->bnt_Cadastrar->setEnabled(true);
                   }
            } else{
                palette.setColor(QPalette::WindowText, Qt::red);
                ui->txt_Erro->setPalette(palette);
                ui->txt_Erro->setText("O usuário deve ter ao menos uma permissão.");
                ui->bnt_Cadastrar->setEnabled(true);
            }
            }
            }
        }
    }
 }



void CadasUser::on_check_SuperU_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_CadasEqui->setChecked(true);
        ui->check_CadasLab->setChecked(true);
        ui->check_Consultar->setChecked(true);
        ui->check_Emprestar->setChecked(true);
    }
}

void CadasUser::on_check_CadasLab_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void CadasUser::on_check_CadasEqui_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void CadasUser::on_check_Consultar_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void CadasUser::on_check_Emprestar_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void CadasUser::on_bnt_Limpar_clicked()
{
    ui->check_CadasEqui->setChecked(false);
    ui->check_CadasLab->setChecked(false);
    ui->check_Consultar->setChecked(false);
    ui->check_Emprestar->setChecked(false);
    ui->check_SuperU->setChecked(false);
}


void CadasUser::mailSent(QString status)
{
    if(status == "Message sent" && falha == true) {
        senha2 = "";
        QPalette palette;
        palette.setColor(QPalette::WindowText, Qt::darkGreen);
        ui->txt_Erro->setPalette(palette);
        ui->txt_Erro->setText("Cadastro realizado com sucesso!\nInformações do novo usuário enviado para o e-mail cadastrado.");
        ui->bnt_Cadastrar->setEnabled(true);
    }
}

void CadasUser::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void CadasUser::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
