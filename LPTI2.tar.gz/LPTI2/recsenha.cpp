#include "recsenha.h"
#include "ui_recsenha.h"
#include "smtp.h"
#include "time.h"
#include "stdlib.h"
#include "QtNetwork"
#include "QSqlQuery"

RecSenha::RecSenha(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RecSenha)
{
    ui->setupUi(this);
     connect(ui->pushButton_2, SIGNAL(clicked()),this, SLOT(close()));
     QNetworkAccessManager nam;
     QNetworkRequest req(QUrl("http://www.google.com"));
     QNetworkReply *reply = nam.get(req);
     QEventLoop loop;
     connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
     loop.exec();
     if(reply->bytesAvailable()) {
        ui->btn_enviar->setEnabled(true);
     } else {
        ui->btn_enviar->setEnabled(false);
        ui->label_2->setText("Sem conexão com a internet");
     }
}

RecSenha::~RecSenha()
{
    delete ui;
}

QString senha, senha1;


void RecSenha::on_btn_enviar_clicked()
{
    ui->btn_enviar->setEnabled(false);
    Smtp* smtp = new Smtp("controledepatrimoniomeca@gmail.com", "bonitasenhorita", "smtp.gmail.com",465);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
    srand((unsigned)time(NULL));
    QString letras = "cba34depqrstufghijql567890mnovwxyz12";
    int num, count = 0;
    int y;
    bool aux = false;

    for (num = 0; num < 10; num++) {
        y = rand() % letras.size();
        senha += letras[y];
    }
    QSqlQuery query;
    QString email = ui->lineEdit->text();
    QString siape = ui->lineEdit_2->text();
    senha1 = senha;
    QString nome;
    QByteArray criptografia = QCryptographicHash::hash(senha.toLocal8Bit(),QCryptographicHash::Sha1).toHex();
    query.prepare("select Nome,SIAPE from usuario where Email='"+email+"' and Estado=true and SIAPE='"+siape+"' ");
    if (query.exec()) {
        while(query.next()) {
            count++;
            nome = query.value(0).toString();
        }
        if (count == 1) {
            aux = true;
        }
    }
    query.prepare("update usuario set Senha='"+criptografia+"' where Email='"+email+"' and Estado=true and SIAPE='"+siape+"' ");
    if (query.exec() && aux == true) {
        smtp->sendMail("controledepatrimoniomeca@gmail.com", email , "Recuperação de Senha - Controle de Patrimônio",
        "Prezado usuário " + nome +",\nSua nova senha para acessar o Controle de Patrimônio é " + senha1);
        ui->label_2->setText("Enviando...");
    } else {
        ui->label_2->setText("E-mail ou SIAPE inválido.");
        senha = "";
        senha1 = "";
        ui->btn_enviar->setEnabled(true);
    }
}

void RecSenha::mailSent(QString status)
{
    if(status == "Message sent") {
        senha = "";
        senha1 = "";
        ui->label_2->setText("Senha alterada. Verifique seu e-mail.");
        ui->btn_enviar->setEnabled(false);
    }
}


