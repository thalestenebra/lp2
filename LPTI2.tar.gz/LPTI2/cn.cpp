#include "cn.h"
#include "QDir"
#include <QDebug>

QSqlDatabase cn:: _db = QSqlDatabase::addDatabase("QMYSQL");
cn *cn::_obj = new cn;

cn::cn(QObject *parent) :
    QObject(parent)
{
    _db.setDatabaseName(QDir::currentPath() + "/mydb.mysql");
    if(_db.open()){
        qDebug() << "Conexão com o banco de dados realizada com êxito" + _db.databaseName() + "<=";
    } else{
        qDebug() << "Problemas para conectar com o banco de dados" + _db.databaseName();
    }
}

cn *cn::obj()
{
    if(!_obj){
        _obj=new cn();
    }
    return _obj;
}

QSqlDatabase cn::db()
{
    return _db;
}
