#include "dadoslogin.h"
#include "QString"

int perm, consequi1 = 0, consequi2 = 0, altEqui1=0;
QString login, nome1, altEqui, idconsequi;

DadosLogin::DadosLogin()
{
}




