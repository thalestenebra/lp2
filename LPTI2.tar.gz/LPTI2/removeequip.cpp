#include "removeequip.h"
#include "ui_removeequip.h"
#include "menuremove.h"
#include "QString"
#include "QSqlQuery"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"
#include "QMessageBox"

RemoveEquip::RemoveEquip(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RemoveEquip)
{
    ui->setupUi(this);
    QStringList CompletionList;
    QSqlQuery query;
    QString cod;

    query.prepare("select IdEquipamento from equipamento where EstadoExcluir=false and EstadoEmpres=false ");
    if(query.exec()){
        while(query.next()){
            cod = query.value(0).toString();
            CompletionList << cod;
        }
    }
    StringCompleter = new QCompleter(CompletionList, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->cod_equip->setCompleter(StringCompleter);
    ui->descricao_equip->setEnabled(false);

    if(altEqui1 == 1){
        altEqui1 = 0;
        ui->cod_equip->setText(altEqui);
    }

    ui->label_nome->setText(nome1);
}

RemoveEquip::~RemoveEquip()
{
    delete ui;
}

void RemoveEquip::on_pushButton_clicked()
{
    MenuRemove menuremove;
    menuremove.setModal(true);
    menuremove.exec();
}


void RemoveEquip::on_btn_confirma_clicked()
{
    QString codigo = ui->cod_equip->text();
    QSqlQuery query;
    int count = 0;
    bool aux = true;

    QPalette paleta;
    paleta.setColor(QPalette::WindowText, Qt::red);
    ui->mensagem->setPalette(paleta);

    //código é valido
    query.prepare("select CodEquipamento from equipamento where EstadoEmpres=false and EstadoExcluir=false "
    "and IdEquipamento='"+codigo+"' ");
    if(query.exec()) {
        while (query.next()) {
            count++;
        }
        if(count != 1) {
            aux = false;
            ui->mensagem->setText("Código do equipamento preenchido não existe");
        }
    }
    count = 0;
    QMessageBox msgBox;
    msgBox.setInformativeText( "Tem certeza que deseja\necluir este equipamento?");
    QAbstractButton *nao = msgBox.addButton("Não", QMessageBox::NoRole);
    msgBox.setIcon(QMessageBox::Question);
    msgBox.exec();
    if(msgBox.clickedButton() == nao) {
        return;
    }

    //'exclusão'
    if(aux == true) {
        query.prepare("update equipamento set EstadoExcluir=true where IdEquipamento='"+codigo+"' and EstadoExcluir=false ");
        if(query.exec()) {
            paleta.setColor(QPalette::WindowText, Qt::darkGreen);
            ui->mensagem->setPalette(paleta);
            ui->mensagem->setText("Equipamento excluído com sucesso");
        } else {
            ui->mensagem->setText("Falha ao acessar banco de dados");
        }
    }
}

void RemoveEquip::on_cod_equip_textChanged()
{
    QString codigo = ui->cod_equip->text();
    QString descricao;
    QSqlQuery query;
    int count = 0;


    query.prepare("select Descricao from equipamento where EstadoEmpres=false and EstadoExcluir=false "
    "and IdEquipamento='"+codigo+"' ");
    if(query.exec()) {
        while(query.next()) {
            count++;
            descricao = query.value(0).toString();
        }
        if (count == 1) {
            ui->descricao_equip->setText(descricao);
            ui->btn_confirma->setEnabled(true);
        } else{
            ui->descricao_equip->setText("");
            ui->btn_confirma->setEnabled(false);
        }
    }
}

void RemoveEquip::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void RemoveEquip::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
