#ifndef CADASUSER_H
#define CADASUSER_H

#include <QDialog>

namespace Ui {
class CadasUser;
}

class CadasUser : public QDialog
{
    Q_OBJECT

public:
    explicit CadasUser(QWidget *parent = 0);
    ~CadasUser();

private slots:
    void on_bnt_Voltar_clicked();

    void on_bnt_Cadastrar_clicked();

    void on_check_SuperU_clicked();

    void on_check_CadasLab_clicked();

    void on_check_CadasEqui_clicked();

    void on_check_Consultar_clicked();

    void on_check_Emprestar_clicked();

    void on_bnt_Limpar_clicked();

    void mailSent(QString);

    void on_cadastro_2_clicked();

    void on_consulta_2_clicked();

private:
    Ui::CadasUser *ui;
};

#endif // CADASUSER_H
